<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Story
 */
?>

<?php the_content(); ?>
